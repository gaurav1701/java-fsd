package com.dao;

import com.entity.User;

public interface UserDAO {

    User getUserById(int userId);

    void updateUser(User user);
}
