package com.assisted_practice.servlet_P9;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionTrackingDemo
 */
@WebServlet("/SessionTrackingDemo")
public class SessionTrackingDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionTrackingDemo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        // Get the current session or create a new one if it doesn't exist
	        HttpSession session = request.getSession();

	        // Set session attributes
	        Integer visitCount = (Integer) session.getAttribute("visitCount");
	        if (visitCount == null) {
	            visitCount = 1;
	        } else {
	            visitCount++;
	        }
	        session.setAttribute("visitCount", visitCount);

	        // Display session information
	        out.println("<html><head><title>Session Tracking Demo</title></head><body>");
	        out.println("<h2>Session Tracking Demo</h2>");
	        out.println("<p>Hello, you have visited this page " + visitCount + " time(s).</p>");
	        out.println("<p>Session ID: " + session.getId() + "</p>");
	        out.println("<p>Session creation time: " + new java.util.Date(session.getCreationTime()) + "</p>");
	        out.println("<p>Session last accessed time: " + new java.util.Date(session.getLastAccessedTime()) + "</p>");
	        out.println("</body></html>");
	}

}
