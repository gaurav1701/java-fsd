package com.lesson3;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Student stu = new Student(101,"Gaurav","Bangaluru");
        
        Configuration config=new Configuration();
        config.configure("hibernate.cfg.xml");
        SessionFactory factory = config.buildSessionFactory();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(stu);
        tx.commit();
        session.close();
        System.out.println("Record Saved Successfully!");
    }
}
