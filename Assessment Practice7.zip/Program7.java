package Assisted_Practice;

public class Program7 {
    // Outer class representing a University
    static class University {
        private String name;

        // Constructor
        public University(String name) {
            this.name = name;
        }

        // Method to display university name
        public void displayUniversityName() {
            System.out.println("University Name: " + name);
        }

        // Inner class representing a Student
        class Student {
            private String name;
            private int id;

            // Constructor
            public Student(String name, int id) {
                this.name = name;
                this.id = id;
            }

            // Method to display student details
            public void displayStudentDetails() {
                System.out.println("Student Name: " + name);
                System.out.println("Student ID: " + id);
            }
        }
    }

    public static void main(String[] args) {
        // Creating an instance of the outer class University
        University university = new University("ABC University");
        university.displayUniversityName();

        // Creating an instance of the inner class Student
        University.Student student = university.new Student("Darsh", 12345);
        
        // Displaying student details
        System.out.println("\nStudent Details:\n");
        student.displayStudentDetails();
    }
}