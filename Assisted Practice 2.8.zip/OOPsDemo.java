package Assisted_Practice_Part2;

class Person {
    private String name;
    private int age;

    // Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter methods for accessing private data
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    // Abstraction: Hiding implementation details by providing high-level methods
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

// Inheritance: Extending a class to create a specialized version
class Student extends Person {
    private int studentId;

    // Constructor
    public Student(String name, int age, int studentId) {
        super(name, age); // Call superclass constructor
        this.studentId = studentId;
    }
    
 // Getter method for accessing student ID
    public int getStudentId() {
        return studentId;
    }

    // Polymorphism: Overriding superclass method with a specialized version
    @Override
    public void displayInfo() {
        super.displayInfo(); // Call superclass method
        System.out.println("Student ID: " + studentId);
    }
}

public class OOPsDemo {
    public static void main(String[] args) {
        // Creating objects
        Person person = new Person("John", 30);
        Student student = new Student("Alice", 20, 12345);

        // Accessing data and methods
        System.out.println("Person:");
        person.displayInfo();
        System.out.println();

        System.out.println("Student:");
        student.displayInfo();
    }
}