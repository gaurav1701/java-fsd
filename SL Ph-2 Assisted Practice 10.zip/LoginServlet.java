package com.assisted_practice;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        // For demonstration, hard-coded valid credentials
        if (email.equals("user@example.com") && password.equals("password")) {
            // Create a session to track the user's login status
            HttpSession session = request.getSession();
            session.setAttribute("user", email);
            response.sendRedirect("dashboard.jsp"); // Redirect to dashboard on successful login
        } else {
            response.sendRedirect("error.jsp"); // Redirect to error page on invalid login
        }
	}

}
