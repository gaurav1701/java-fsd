package Assisted_Practice_3;

import java.util.Scanner;

class Node1 {
    int data;
    Node1 next;

    public Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

public class CircularLinkedList {
    Node1 head;

    public void insertSorted(int newData) {
        Node1 newNode = new Node1(newData);

        if (head == null) {
            head = newNode;
            head.next = head;
        } else if (newNode.data <= head.data) {
            Node1 last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = newNode;
        } else {
            Node1 current = head;
            while (current.next != head && current.next.data < newNode.data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public Node1 getLastNode() {
        Node1 temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }
        return temp;
    }

    public void printList() {
        if (head == null) {
            System.out.println("Circular linked list is empty");
            return;
        }

        Node1 temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }

    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the circular linked list: ");
        int n = scanner.nextInt();

        System.out.println("Enter the elements of the circular linked list in sorted order:");
        for (int i = 0; i < n; i++) {
            int data = scanner.nextInt();
            list.insertSorted(data);
        }

        System.out.println("Circular Linked List after insertion:");
        list.printList();

        scanner.close();
    }
}

