package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sl3AssistedPractice1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sl3AssistedPractice1Application.class, args);
	}

}
