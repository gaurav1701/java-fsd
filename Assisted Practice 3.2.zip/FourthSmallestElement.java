package Assisted_Practice_3;

import java.util.Arrays;

public class FourthSmallestElement {
    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List has less than 4 elements");
            return -1; // return -1 if the list has less than 4 elements
        }

        // Sort the array
        Arrays.sort(arr);

        // Return the fourth element from the sorted array
        return arr[3];
    }

    public static void main(String[] args) {
        int[] arr = {10, 5, 20, 3, 15, 7}; // Example unsorted list
        int fourthSmallest = findFourthSmallest(arr);
        if (fourthSmallest != -1) {
            System.out.println("Fourth smallest element: " + fourthSmallest);
        }
    }
}
