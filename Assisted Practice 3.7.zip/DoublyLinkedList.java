package Assisted_Practice_3;

class Node2 {
    int data;
    Node2 prev;
    Node2 next;

    public Node2(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

public class DoublyLinkedList {
    Node2 head;
    Node2 tail;

    public void insert(int newData) {
        Node2 newNode = new Node2(newData);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void traverseForward() {
        System.out.println("Traversal in forward direction:");
        Node2 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void traverseBackward() {
        System.out.println("Traversal in backward direction:");
        Node2 current = tail;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();

        // Inserting elements into the doubly linked list
        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);
        list.insert(5);

        // Traversing the doubly linked list in forward direction
        list.traverseForward();

        // Traversing the doubly linked list in backward direction
        list.traverseBackward();
    }
}
