package Assisted_Practice_3;

import java.util.Scanner;
import java.util.Stack;

public class StackElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stack<Integer> stack = new Stack<>();

        System.out.print("Enter the number of elements to push onto the stack: ");
        int n = scanner.nextInt();

        System.out.println("Enter the elements to push onto the stack:");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            stack.push(element);
        }

        System.out.println("Stack elements after pushing:");
        System.out.println(stack);

        System.out.println("Popping an element from the stack:");
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);

        System.out.println("Stack elements after popping:");
        System.out.println(stack);

        if (!stack.isEmpty()) {
            System.out.println("Top element of the stack: " + stack.peek());
        } else {
            System.out.println("Stack is empty.");
        }

        scanner.close();
    }
}
