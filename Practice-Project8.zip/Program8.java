package Assisted_Practice;

public class Program8 {
	
	public static void main(String[] args) {
        // Creating a string
        String str = "Hello world!";
        System.out.println("Original String: " + str+"\n");

        // Converting string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);
        System.out.println("StringBuffer: " + stringBuffer+"\n");

        // Converting string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);
        System.out.println("StringBuilder: " + stringBuilder);
    }

}
