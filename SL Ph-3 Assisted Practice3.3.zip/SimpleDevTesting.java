package com.test;

import org.junit.Test;

import com.dev.SimpleOperations;

import junit.framework.Assert;

public class SimpleDevTesting {
	
	@Test
	public void testPosAddition() {
		
		SimpleOperations sim = new SimpleOperations();
		int actual = sim.Addition(10, 20);
		int expected = 30;
		
		Assert.assertEquals(expected,actual);
		//System.out.println(res);
		
	}
	
	@Test
	public void testNosAddition() {
		
		SimpleOperations sim = new SimpleOperations();
		int actual = sim.Addition(-10, -20);
		int expected = -30;
		
		Assert.assertEquals(expected,actual);
		//System.out.println(res);
		
	}

	
	@Test
	public void testPosNosAddition() {
		
		SimpleOperations sim = new SimpleOperations();
		int actual = sim.Addition(10, -2);
		int expected = 8;
		
		Assert.assertEquals(expected,actual);
		//System.out.println(res);
		
	}
	
	@Test
	public void testSmallValFromArray() {
		
		SimpleOperations sim = new SimpleOperations();
		int actual =sim.SmallValFromArray(new int[] {10,2,8,4});
		int expected = 0;
		Assert.assertEquals(expected, actual);
		
	}


}
