package Assisted_Practice_Part2;

interface Animal {
    void eat();
}

// Define two interfaces that extend the common interface
interface Herbivore extends Animal {
    void graze();
}

interface Carnivore extends Animal {
    void hunt();
}

// Define a class that implements both interfaces
class Omnivore implements Herbivore, Carnivore {
    public void eat() {
        System.out.println("Omnivore is eating.");
    }

    public void graze() {
        System.out.println("Omnivore is grazing.");
    }

    public void hunt() {
        System.out.println("Omnivore is hunting.");
    }
}

public class DiamondProblemDemo {
    public static void main(String[] args) {
        // Create an instance of Omnivore
        Omnivore omnivore = new Omnivore();

        // Call methods
        omnivore.eat();  // From Animal interface
        omnivore.graze();  // From Herbivore interface
        omnivore.hunt();  // From Carnivore interface
    }
}
