package com.assisted_practice_program5;

import java.sql.*;

public class DatabaseExample {
	
	private static final String url = "jdbc:mysql://localhost:3306/";
    private static final String username = "root";
    private static final String password = "Gaurav@123";

	public static void main(String[] args) {
		
		 try (Connection conn = DriverManager.getConnection(url, username, password)) {
	            System.out.println("Connected to MySQL server!");

	            // Step 1: Create a new database
	            String databaseName = "Mydatabase1";
	            createDatabase(conn, databaseName);

	            // Step 2: Select the newly created database
	            selectDatabase(conn, databaseName);

	            // Step 3: Drop (delete) the database
	            dropDatabase(conn, databaseName);

	        } catch (SQLException e) {
	            System.err.println("Error: " + e.getMessage());
	        }
	    }

	   private static void createDatabase(Connection conn, String databaseName) throws SQLException {
	        String sql = "CREATE DATABASE " + databaseName;
	        try (Statement statement = conn.createStatement()) {
	            statement.executeUpdate(sql);
	            System.out.println("Database '" + databaseName + "' created successfully.");
	        }
	    }

	    private static void selectDatabase(Connection conn, String databaseName) throws SQLException {
	        String sql = "USE " + databaseName;
	        try (Statement statement = conn.createStatement()) {
	            statement.executeUpdate(sql);
	            System.out.println("Selected database: " + databaseName);
	        }
	    }

	   private static void dropDatabase(Connection conn, String databaseName) throws SQLException {
	        String sql = "DROP DATABASE " + databaseName;
	        try (Statement statement = conn.createStatement()) {
	            statement.executeUpdate(sql);
	            System.out.println("Database '" + databaseName + "' dropped successfully.");
	        }
		

	   }

}
