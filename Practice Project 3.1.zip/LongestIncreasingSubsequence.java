package Practice_Project_3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class LongestIncreasingSubsequence {
	
	 public static List<Integer> findLongestIncreasingSubsequence(int[] nums) {
	        int n = nums.length;
	        int[] dp = new int[n]; // dp[i] stores the length of the LIS ending at index i
	        Arrays.fill(dp, 1); // Initialize all LIS lengths to 1
	        
	        // Find the length of the LIS ending at each index
	        for (int i = 1; i < n; i++) {
	            for (int j = 0; j < i; j++) {
	                if (nums[i] > nums[j]) {
	                    dp[i] = Math.max(dp[i], dp[j] + 1);
	                }
	            }
	        }
	        
	        // Find the maximum LIS length
	        int maxLISLength = 0;
	        for (int length : dp) {
	            maxLISLength = Math.max(maxLISLength, length);
	        }
	        
	        // Construct the LIS using backtracking
	        List<Integer> longestIncreasingSubsequence = new ArrayList<>();
	        int maxLengthIndex = -1;
	        for (int i = n - 1; i >= 0; i--) {
	            if (dp[i] == maxLISLength) {
	                maxLengthIndex = i;
	                break;
	            }
	        }
	        if (maxLengthIndex != -1) {
	            longestIncreasingSubsequence.add(nums[maxLengthIndex]);
	            int maxLength = maxLISLength - 1;
	            for (int i = maxLengthIndex - 1; i >= 0; i--) {
	                if (nums[i] < nums[maxLengthIndex] && dp[i] == maxLength) {
	                    longestIncreasingSubsequence.add(nums[i]);
	                    maxLength--;
	                    maxLengthIndex = i;
	                }
	            }
	        }
	        return longestIncreasingSubsequence;
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the number of elements in the array: ");
	        int n = scanner.nextInt();
	        int[] nums = new int[n];
	        System.out.println("Enter the elements of the array:");
	        for (int i = 0; i < n; i++) {
	            nums[i] = scanner.nextInt();
	        }
	        List<Integer> lis = findLongestIncreasingSubsequence(nums);
	        System.out.println("Longest Increasing Subsequence: " + lis);
	        scanner.close();
	    }
	}

