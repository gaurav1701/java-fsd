package Assisted_Practice_Part2;

import java.util.Scanner;

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Prompt the user to enter two numbers
            System.out.print("Enter numerator: ");
            int numerator = scanner.nextInt();

            System.out.print("Enter denominator: ");
            int denominator = scanner.nextInt();

            // Perform division
            double result = divide(numerator, denominator);
            System.out.println("Result of division: " + result);
        } catch (ArithmeticException e) {
            // Handle arithmetic exception (e.g., division by zero)
            System.out.println("Error: Division by zero is not allowed.");
        } catch (Exception e) {
            // Handle any other exception
            System.out.println("Error: An unexpected error occurred.");
            e.printStackTrace();
        } finally {
            // Close the scanner
            scanner.close();
        }

        System.out.println("Program finished.");
    }

    public static double divide(int numerator, int denominator) {
        // Perform division
        return numerator / (double) denominator;
    }
}
