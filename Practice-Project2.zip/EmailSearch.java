package Practice_Project_2;

import java.util.Scanner;

public class EmailSearch {
	
	public static void main(String[] args) {
        // Array of email IDs
        String[] emailIds = {"arjun@example.com", "arun@example.com", "darsh@example.com", "vimal@example.com"};

        // Print the array of email IDs
        System.out.println("Array of email IDs:");
        for (String email : emailIds) {
            System.out.println(email);
        }
        
        // Prompt the user to enter an email ID to search for
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter an email ID to search: ");
        String searchEmail = scanner.nextLine();

        // Perform the search
        boolean found = false;
        for (String email : emailIds) {
            if (email.equalsIgnoreCase(searchEmail)) {
                found = true;
                break;
            }
        }

        // Display the result
        if (found) {
            System.out.println("Email ID found in the array.");
        } else {
            System.out.println("Email ID not found in the array.");
        }

        scanner.close();
    }

}
