package Assisted_Practice;

public class Program1 {
	
	public static void main(String[] args) {
        // Implicit type casting (Widening Conversion)
        int numInt = 599;
        long numLong = numInt; // Implicit casting from int to long
        float numFloat = numLong; // Implicit casting from long to float
        double numDouble = numFloat; // Implicit casting from float to double

        System.out.println("Implicit Type Casting:");
        System.out.println("int: " + numInt);
        System.out.println("long: " + numLong);
        System.out.println("float: " + numFloat);
        System.out.println("double: " + numDouble);

        // Explicit type casting (Narrowing Conversion)
        double bigDouble = 2897.43589;
        float bigFloat = (float) bigDouble; // Explicit casting from double to float
        long bigLong = (long) bigFloat; // Explicit casting from float to long
        int bigInt = (int) bigLong; // Explicit casting from long to int

        System.out.println("\nExplicit Type Casting:");
        System.out.println("double: " + bigDouble);
        System.out.println("float: " + bigFloat);
        System.out.println("long: " + bigLong);
        System.out.println("int: " + bigInt);
    }

}
