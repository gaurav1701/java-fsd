package Assisted_Practice;

public class Program4 {
	
	private String name;
    private int age;

    // Default constructor
    public Program4() {
        name = "Anil";
        age = 30;
    }

    // Parameterized constructor
    public Program4(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    public Program4(Program4 other) {
        this.name = other.name;
        this.age = other.age;
    }

    // Method to display object details
    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        // Creating objects using different constructors
    	Program4 obj1 = new Program4(); // Default constructor
    	Program4 obj2 = new Program4("Darsh", 25); // Parameterized constructor
    	Program4 obj3 = new Program4(obj2); // Copy constructor

        // Displaying object details
        System.out.println("Object 1:");
        obj1.display();
        System.out.println("\nObject 2:");
        obj2.display();
        System.out.println("\nObject 3:");
        obj3.display();
    }

}
