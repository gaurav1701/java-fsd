package Assisted_Practice;

public class Program9 {
	
	public static void main(String[] args) {
        // Declaration and initialization of an array of integers
        int[] numbers = {10, 20, 30, 40, 50};

        // Accessing elements of the array using index
        System.out.println("Elements of the array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Element at index " + i + ": " + numbers[i]);
        }

        // Finding the sum of elements in the array
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of elements: " + sum);

        // Declaration and initialization of an array of strings
        String[] fruits = {"Apple", "Banana", "Orange", "Mango"};

        // Accessing elements of the array using index
        System.out.println("\nFruits in the array:");
        for (int i = 0; i < fruits.length; i++) {
            System.out.println("Fruit at index " + i + ": " + fruits[i]);
        }
    }

}
