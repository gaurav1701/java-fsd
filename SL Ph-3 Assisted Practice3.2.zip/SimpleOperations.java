package com.dev;

public class SimpleOperations {
	
	public int Addition(int x, int y) {
		
		return x+y; 
	}

}
