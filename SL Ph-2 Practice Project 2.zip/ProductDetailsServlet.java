package practice_project_2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductDetailsServlet
 */
@WebServlet("/ProductDetailsServlet")
public class ProductDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String productId = request.getParameter("productId");
        if (productId != null && !productId.isEmpty()) {
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "Gaurav@123");
                String query = "SELECT * FROM products WHERE id = ?";
                PreparedStatement statement = conn.prepareStatement(query);
                statement.setString(1, productId);

                ResultSet result = statement.executeQuery();

                if (result.next()) {
                    String name = result.getString("name");
                    double price = result.getDouble("price");
                    String description = result.getString("description");

                    out.println("<h2>Product Details</h2>");
                    out.println("<p><strong>Name:</strong> " + name + "</p>");
                    out.println("<p><strong>Price:</strong> $" + price + "</p>");
                    out.println("<p><strong>Description:</strong> " + description + "</p>");
                } else {
                    out.println("<p>Product not found!</p>");
                }

                conn.close();
            } catch (SQLException e) {
                out.println("<p>Error accessing database: " + e.getMessage() + "</p>");
            }
        } else {
            out.println("<p>Please provide a valid product ID.</p>");
        }
	}

}
