package com.assisted_practice.servlet_P4;

public class GreetService {
	
	public String getGreeting() {
        return "Hello from Servlet!";
    }

}
