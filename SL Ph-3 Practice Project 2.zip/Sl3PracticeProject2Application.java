package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sl3PracticeProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sl3PracticeProject2Application.class, args);
	}

}
