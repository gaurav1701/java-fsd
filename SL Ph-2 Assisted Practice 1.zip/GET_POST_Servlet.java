package com.assisted_practice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GET_POST_Servlet
 */
@WebServlet("/GET_POST_Servlet")
public class GET_POST_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GET_POST_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		  // Prepare HTML response with centered text
	    PrintWriter out = response.getWriter();
	    out.println("<!DOCTYPE html>");
	    out.println("<html>");
	    out.println("<head>");
	    out.println("<title>GET Request Processed</title>");
	    out.println("<style>");
	    out.println("body { text-align: center; }"); // Center-align text within the body
	    out.println("</style>");
	    out.println("</head>");
	    out.println("<body>");
	    out.println("<h1>GET Request Processed</h1>");
	    out.println("</body>");
	    out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		   
        // Prepare HTML response with centered text
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>POST Request Processed</title>");
        out.println("<style>");
        out.println("body { text-align: center; }"); // Center-align text within the body
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>POST Request Processed</h1>");
        out.println("</body>");
        out.println("</html>");
	}

}
