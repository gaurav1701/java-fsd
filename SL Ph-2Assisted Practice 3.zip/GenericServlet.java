package com.assisted_practice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GenericServlet
 */
@WebServlet("/GenericServlet")
public class GenericServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenericServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

        // Get the PrintWriter object to write HTML response
        PrintWriter out = response.getWriter();

        // Write HTML response content
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Generic Servlet Example</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Hello from Generic Servlet!</h1>");
        out.println("<p>This is a demonstration of a Generic Servlet.</p>");
        out.println("</body>");
        out.println("</html>");
	}

}
