package Assisted_Practice_3;

import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class LinkedList {
    Node head;

    public void deleteNode(int key) {
        Node temp = head;
        Node prev = null;

        // If the head node itself holds the key to be deleted
        if (temp != null && temp.data == key) {
            head = temp.next;
            return;
        }

        // Search for the key to be deleted, keep track of the previous node
        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        // If the key was not present in the linked list
        if (temp == null)
            return;

        // Unlink the node from the linked list
        prev.next = temp.next;
    }

    public void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the linked list: ");
        int n = scanner.nextInt();

        System.out.println("Enter the elements of the linked list:");
        for (int i = 0; i < n; i++) {
            int data = scanner.nextInt();
            if (i == 0) {
                list.head = new Node(data);
            } else {
                Node newNode = new Node(data);
                Node last = list.head;
                while (last.next != null) {
                    last = last.next;
                }
                last.next = newNode;
            }
        }

        System.out.println("Original Linked List:");
        list.printList();

        System.out.print("Enter the key to delete: ");
        int key = scanner.nextInt();
        list.deleteNode(key);

        System.out.println("Linked List after deleting first occurrence of " + key + ":");
        list.printList();

        scanner.close();
    }
}
