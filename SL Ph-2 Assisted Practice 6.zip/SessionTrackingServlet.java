package com.assisted_practice.servlet_P6;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SessionTrackingServlet
 */
@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionTrackingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

        // Check if a cookie named "sessionId" exists
        Cookie[] cookies = request.getCookies();
        String sessionId = null;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("sessionId")) {
                    sessionId = cookie.getValue();
                    break;
                }
            }
        }

        // If sessionId exists, show session ID; otherwise, create a new cookie with a session ID
        if (sessionId != null && !sessionId.isEmpty()) {
            response.getWriter().println("<html><body>");
            response.getWriter().println("<h1>Your Session ID:</h1>");
            response.getWriter().println("<p>" + sessionId + "</p>");
            response.getWriter().println("</body></html>");
        } else {
            // Create a new session ID
            sessionId = "SID" + System.currentTimeMillis();
            Cookie cookie = new Cookie("sessionId", sessionId);
            response.addCookie(cookie);

            response.getWriter().println("<html><body>");
            response.getWriter().println("<h1>New Session ID Created:</h1>");
            response.getWriter().println("<p>" + sessionId + "</p>");
            response.getWriter().println("</body></html>");
        }
	}

}
