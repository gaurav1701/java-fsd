package com.assisted_practice.servlet_P7;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CounterServlet
 */
@WebServlet("/CounterServlet")
public class CounterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CounterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 // Get the current count from the session or initialize it to 0
        Integer count = (Integer) request.getSession().getAttribute("count");
        if (count == null) {
            count = 0;
        }
        
        // Increment the count
        count++;
        
        // Store the updated count in the session
        request.getSession().setAttribute("count", count);
        
        // Set the response content type
        response.setContentType("text/html");
        
        // Write the response
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>URL Rewriting Session Tracking</title></head><body>");
        out.println("<h2>Page Visits Counter</h2>");
        out.println("<p>Number of Visits: " + count + "</p>");
        out.println("<p><a href=\"" + response.encodeURL("CounterServlet") + "\">Refresh</a></p>");
        out.println("</body></html>");
    }

}
