package com.quiz_portal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*public class QuizDAO {

    private static final String SELECT_ALL_QUIZZES = "SELECT * FROM quizzes";
    private static final String INSERT_QUIZ = "INSERT INTO quizzes (quiz_name, description) VALUES (?, ?)";

    // Method to retrieve all quizzes from the database
    public static List<Quiz> getAllQuizzes() {
        List<Quiz> quizzes = new ArrayList<>();

        try (Connection connection = Database.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_QUIZZES);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int quizId = resultSet.getInt("quiz_id");
                String quizName = resultSet.getString("quiz_name");
                String description = resultSet.getString("description");

                // Create a Quiz object and add it to the list
                Quiz quiz = new Quiz();
                quiz.setQuizId(quizId);
                quiz.setQuizName(quizName);
                quiz.setDescription(description);

                // Add quiz to the list
                quizzes.add(quiz);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception (logging, throwing custom exceptions, etc.)
        }

        return quizzes;
    }

    // Method to create a new quiz in the database
    public static boolean createQuiz(Quiz quiz) {
        try (Connection connection = Database.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_QUIZ)) {

            // Set parameters for the prepared statement
            statement.setString(1, quiz.getQuizName());
            statement.setString(2, quiz.getDescription());

            // Execute the insert query
            int rowsInserted = statement.executeUpdate();

            // Return true if the quiz was inserted successfully
            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception (logging, throwing custom exceptions, etc.)
            return false;
        }
    }

    // Additional methods can be added for updating and deleting quizzes if needed
}*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class QuizDAO {

    private static final String SELECT_ALL_QUIZZES = "SELECT * FROM quizzes";
    private static final String INSERT_QUIZ = "INSERT INTO quizzes (quiz_name, description) VALUES (?, ?)";

    // Method to retrieve all quizzes from the database
    public static List<Quiz> getAllQuizzes() {
        List<Quiz> quizzes = new ArrayList<>();

        try (Connection connection = Database.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_QUIZZES);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int quizId = resultSet.getInt("quiz_id");
                String quizName = resultSet.getString("quiz_name");
                String description = resultSet.getString("description");

                // Create a Quiz object and add it to the list
                Quiz quiz = new Quiz();
                quiz.setQuizId(quizId);
                quiz.setQuizName(quizName);
                quiz.setDescription(description);

                // Add quiz to the list
                quizzes.add(quiz);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception (logging, throwing custom exceptions, etc.)
        }

        return quizzes;
    }

    // Method to create a new quiz in the database
    public static boolean createQuiz(Quiz quiz) {
        boolean quizCreated = false;

        try (Connection connection = Database.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_QUIZ)) {

            statement.setString(1, quiz.getQuizName());
            statement.setString(2, quiz.getDescription());

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                quizCreated = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception (logging, throwing custom exceptions, etc.)
        }

        return quizCreated;
    }

    // Other methods can be added for updating/deleting quizzes, retrieving specific quizzes, etc.
    
    private static final String SELECT_QUESTIONS_FOR_QUIZ = "SELECT * FROM questions WHERE quiz_id = ?";

    // Method to retrieve questions for a specific quiz
    public static List<Question> getQuestionsForQuiz(int quizId) {
        List<Question> questions = new ArrayList<>();

        try (Connection connection = Database.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_QUESTIONS_FOR_QUIZ)) {

            statement.setInt(1, quizId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int questionId = resultSet.getInt("question_id");
                String questionText = resultSet.getString("question_text");

                // Create a Question object and add it to the list
                Question question = new Question();
                question.setQuestionId(questionId);
                question.setQuestionText(questionText);

                // Add question to the list
                questions.add(question);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception (logging, throwing custom exceptions, etc.)
        }

        return questions;
    }

}

/*public class QuizDAO {

    private static final String SELECT_ALL_QUIZZES = "SELECT * FROM quizzes";

    // Method to retrieve all quizzes from the database
    public static List<Quiz> getAllQuizzes() {
        List<Quiz> quizzes = new ArrayList<>();

        try (Connection connection = Database.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_QUIZZES);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int quizId = resultSet.getInt("quiz_id");
                String quizName = resultSet.getString("quiz_name");
                String description = resultSet.getString("description");

                // Retrieve questions for the quiz
                List<Question> questions = getQuestionsForQuiz(quizId);

                // Create a Quiz object and add to list
                Quiz quiz = new Quiz();
                quiz.setQuizId(quizId);
                quiz.setQuizName(quizName);
                quiz.setDescription(description);
                quiz.setQuestions(questions);

                quizzes.add(quiz);
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Add more detailed logging or error handling
        }

        return quizzes;
    }

    // Method to retrieve questions for a specific quiz from the database
    private static List<Question> getQuestionsForQuiz(int quizId) {
        // Implement code to fetch questions based on quizId from your database
        // Return a List<Question> containing questions for the specified quiz
        return new ArrayList<>(); // Placeholder implementation
    }
}*/