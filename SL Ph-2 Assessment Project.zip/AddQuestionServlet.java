package com.quiz_portal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddQuestionServlet
 */
/*@WebServlet("/AddQuestionServlet")
public class AddQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/quizdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Gaurav@123";


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
/*	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 // Retrieve form data
        String questionText = request.getParameter("questionText");
        String correctAnswer = request.getParameter("correctAnswer");

        // Add question to the database
        boolean success = addQuestion(questionText, correctAnswer);

        if (success) {
            // Redirect to admin dashboard with success message
            response.sendRedirect("admin_dashboard.jsp?question_added=1");
        } else {
            // Redirect back to add question page with error message
            response.sendRedirect("create_quiz.jsp?error=1");
        }
    }

    private boolean addQuestion(String questionText, String correctAnswer) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO questions (question_text, correct_answer) VALUES (?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, questionText);
                statement.setString(2, correctAnswer);
                int rowsInserted = statement.executeUpdate();
                return rowsInserted > 0; // Returns true if the question is added successfully
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false on any database error
        }
	}

}*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AddQuestionServlet")
public class AddQuestionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/quizdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Gaurav@123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String quizName = request.getParameter("quizName");
        int questionCount = 1; // Start with the first question

        try {
            // Process each submitted question dynamically until no more questions are found
            while (request.getParameter("questionText" + questionCount) != null) {
                String questionText = request.getParameter("questionText" + questionCount);
                String optionA = request.getParameter("optionA" + questionCount);
                String optionB = request.getParameter("optionB" + questionCount);
                String optionC = request.getParameter("optionC" + questionCount);
                String optionD = request.getParameter("optionD" + questionCount);
                String correctOption = request.getParameter("correctOption" + questionCount);

                // Add question to the database
                boolean success = addQuestion(quizName, questionText, optionA, optionB, optionC, optionD, correctOption);

                if (!success) {
                    // If any question fails to be added, redirect back with an error message
                    response.sendRedirect("create_quiz.jsp?error=1");
                    return; // Exit the loop and servlet method
                }

                questionCount++; // Move to the next question
            }

            // If all questions are added successfully, redirect to admin dashboard
            response.sendRedirect("admin_dashboard.jsp?quiz_added=1");

        } catch (SQLException e) {
            // Log any database-related errors
            e.printStackTrace();
            response.sendRedirect("create_quiz.jsp?error=1");
        }
    }

    private boolean addQuestion(String quizName, String questionText, String optionA, String optionB, String optionC,
                                String optionD, String correctOption) throws SQLException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_option) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Assuming you have a quiz_id associated with the quizName (retrieve it from database or another source)
                int quizId = getQuizIdByName(quizName); // Custom method to get quiz_id based on quizName

                statement.setInt(1, quizId);
                statement.setString(2, questionText);
                statement.setString(3, optionA);
                statement.setString(4, optionB);
                statement.setString(5, optionC);
                statement.setString(6, optionD);
                statement.setString(7, correctOption);

                int rowsInserted = statement.executeUpdate();
                return rowsInserted > 0; // Returns true if the question is added successfully
            }
        }
    }

    // Example method to retrieve quiz_id by quizName (implement as needed)
    private int getQuizIdByName(String quizName) throws SQLException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT quiz_id FROM quizzes WHERE quiz_name = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, quizName);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getInt("quiz_id");
                    }
                }
            }
        }
        throw new SQLException("Quiz not found for quizName: " + quizName);
    }
}