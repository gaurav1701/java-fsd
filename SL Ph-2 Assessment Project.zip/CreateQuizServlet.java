package com.quiz_portal;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/CreateQuizServlet")
public class CreateQuizServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve quiz name from the form data
        String quizName = request.getParameter("quizName");

        // Optionally, retrieve other form data to create the quiz (e.g., questions, options, etc.)

        // Example: Save the quiz data to the database (you can implement this logic)
        Quiz newQuiz = new Quiz();
        newQuiz.setQuizName(quizName);

        // Save the new quiz to the database using QuizDAO or another data access method
        boolean quizCreated = QuizDAO.createQuiz(newQuiz); // Implement createQuiz method in QuizDAO

        if (quizCreated) {
            // Quiz created successfully
            response.sendRedirect("admin_dashboard.jsp?quiz_created=true");
        } else {
            // Quiz creation failed
            response.sendRedirect("create_quiz.jsp?error=quiz_creation_failed");
        }
    }
}
