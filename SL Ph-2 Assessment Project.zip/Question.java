package com.quiz_portal;
	
	public class Question {
		
	    private int questionId;
	    private String questionText;

	    // Getters and Setters
	    public int getQuestionId() {
	        return questionId;
	    }

	    public void setQuestionId(int questionId) {
	        this.questionId = questionId;
	    }

	    public String getQuestionText() {
	        return questionText;
	    }

	    public void setQuestionText(String questionText) {
	        this.questionText = questionText;
	    }
	}