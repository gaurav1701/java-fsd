package Assisted_Practice;

public class Program3 {
	
	// Method with no return value and no parameters
    public static void greet() {
        System.out.println("Hello!");
    }

    // Method with return value and parameters
    public static int add(int a, int b) {
        return a + b;
    }

    // Method overloading: Same name but different parameters
    public static double add(double a, double b) {
        return a + b;
    }

    // Method with a return value but no parameters
    public static String getMessage() {
        return "Welcome!";
    }
    
    // Method to check if a number is even
    public static boolean isEven(int num) {
        return num % 2 == 0;
    }

    // Method to find the maximum of two numbers
    public static int max(int a, int b) {
        return (a > b) ? a : b;
    }
    
    public static void main(String[] args) {
        // Calling a method with no return value and no parameters
        greet();

        // Calling a method with return value and parameters
        int sumInt = add(5, 3);
        System.out.println("Sum (int): " + sumInt);

        // Calling an overloaded method
        double sumDouble = add(5.5, 3.3);
        System.out.println("Sum (double): " + sumDouble);

        // Calling a method with a return value but no parameters
        String message = getMessage();
        System.out.println("Message: " + message);

        // Alternative way to call a method with return value and parameters
        System.out.println("Sum (int): " + add(10, 20));
        
        // Calling a method to check if a number is even
        int number = 7;
        boolean isEvenNumber = isEven(number);
        System.out.println(number + " is even: " + isEvenNumber);
        
        // Calling a method to find the maximum of two numbers
        int maxNumber = max(25, 18);
        System.out.println("Maximum number: " + maxNumber);
    }

}
