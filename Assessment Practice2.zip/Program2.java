package Assisted_Practice;

class Outer {
    private int privateVar;
    int defaultVar;
    protected int protectedVar;
    public int publicVar;

    // Constructor
    public Outer() {
        privateVar = 10;
        defaultVar = 20;
        protectedVar = 30;
        publicVar = 40;
    }

    // Inner class with default access modifier
    class Inner {
        // Method to access variables of Outer class
        public void display() {
            System.out.println("Private variable: " + privateVar);
            System.out.println("Default variable: " + defaultVar);
            System.out.println("Protected variable: " + protectedVar);
            System.out.println("Public variable: " + publicVar);
        }
    }
}

public class Program2 {
	
	public static void main(String[] args) {
        Outer outer = new Outer();
        Outer.Inner inner = outer.new Inner();
        inner.display();
    }

}
