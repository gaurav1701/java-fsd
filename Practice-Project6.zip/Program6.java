package Assisted_Practice;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Program6 {
	
	public static void main(String[] args) {
        // HashMap
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);

        // TreeMap
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Apple", 100);
        treeMap.put("Banana", 50);
        treeMap.put("Orange", 80);

        // Displaying elements of each map
        System.out.println("HashMap:");
        System.out.println(hashMap);
        System.out.println("\nTreeMap:");
        System.out.println(treeMap);
    }

}
