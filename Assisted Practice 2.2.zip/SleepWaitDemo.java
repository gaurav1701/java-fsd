package Assisted_Practice_Part2;

class SleepWaitDemo {
    public static void main(String[] args) {
        Thread sleepThread = new Thread(() -> {
            System.out.println("Sleeping thread started");
            try {
                // Sleep for 3 seconds
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Sleeping thread ended");
        });

        Thread waitThread = new Thread(() -> {
            System.out.println("Waiting thread started");
            synchronized (SleepWaitDemo.class) {
                try {
                    // Wait for 3 seconds
                    SleepWaitDemo.class.wait(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Waiting thread ended");
        });

        sleepThread.start();
        waitThread.start();
    }
}
