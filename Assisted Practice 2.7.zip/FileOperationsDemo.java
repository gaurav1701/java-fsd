package Assisted_Practice_Part2;

import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class FileOperationsDemo {
    public static void main(String[] args) {
        // Define the file path
        Path filePath = Paths.get("abc.txt");

        // Create a file
        try {
            Files.createFile(filePath);
            System.out.println("File created: " + filePath.getFileName());
        } catch (FileAlreadyExistsException e) {
            System.out.println("File already exists.");
        } catch (Exception e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }

        // Write to the file
        try {
            String data = "Hello, World!\nThis is a test file.";
            Files.write(filePath, data.getBytes());
            System.out.println("Data written to the file successfully.");
        } catch (Exception e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        // Read from the file
        try {
            String content = Files.readString(filePath);
            System.out.println("Contents of the file:");
            System.out.println(content);
        } catch (Exception e) {
            System.out.println("An error occurred while reading from the file.");
            e.printStackTrace();
        }

        // Update the file
        try {
            String newData = "\nThis line is appended to the file.";
            Files.write(filePath, newData.getBytes(), StandardOpenOption.APPEND);
            System.out.println("Data appended to the file successfully.");
        } catch (Exception e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }

        // Delete the file
        try {
            Files.delete(filePath);
            System.out.println("File deleted successfully.");
        } catch (Exception e) {
            System.out.println("Failed to delete the file.");
            e.printStackTrace();
        }
    }
}
