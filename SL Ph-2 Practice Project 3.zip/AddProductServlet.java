package com.practice_project3;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.practice_project3.Product;
/**
 * Servlet implementation class AddProductServlet
 */
@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 try {
	            // Retrieve form data
	            String name = request.getParameter("name");
	            String description = request.getParameter("description");
	            double price = Double.parseDouble(request.getParameter("price"));

	            // Create Product object with form data
	            Product product = new Product();
	            product.setName(name);
	            product.setDescription(description);
	            product.setPrice(price);

	            // Initialize Hibernate session factory and session
	            Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
	            try (SessionFactory sessionFactory = cfg.buildSessionFactory();
	                 Session session = sessionFactory.openSession()) {

	                // Begin transaction
	                Transaction transaction = session.beginTransaction();

	                // Save the product to the database
	                session.save(product);

	                // Commit transaction
	                transaction.commit();

	                // Redirect to homepage after successful addition
	                response.sendRedirect("addProduct.jsp");
	            } catch (Exception e) {
	                // Handle Hibernate-related exceptions
	                e.printStackTrace();
	                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error adding product to database");
	            }
	        } catch (NumberFormatException e) {
	            // Handle number format exception (e.g., invalid price format)
	            e.printStackTrace();
	            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid price format");
	        } catch (Exception e) {
	            // Handle other exceptions (e.g., general servlet processing error)
	            e.printStackTrace();
	            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
	        }
	}

}
