package Assisted_Practice_4;

import java.util.Scanner;

public class ExponentialSearch {
    // Function to perform binary search
    public static int binarySearch(int[] arr, int target, int low, int high) {
        while (low <= high) {
            int mid = low + (high - low) / 2;

            // Check if target is present at mid
            if (arr[mid] == target) {
                return mid;
            }
            // If target greater, ignore left half
            else if (arr[mid] < target) {
                low = mid + 1;
            }
            // If target is smaller, ignore right half
            else {
                high = mid - 1;
            }
        }
        // If target is not present in the array
        return -1;
    }

    // Function to perform exponential search
    public static int exponentialSearch(int[] arr, int target) {
        int size = arr.length;
        if (arr[0] == target) {
            return 0; // If element found at index 0
        }

        int i = 1;
        while (i < size && arr[i] <= target) {
            i *= 2;
        }

        // Call binary search for the found range
        return binarySearch(arr, target, i / 2, Math.min(i, size - 1));
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the size of the array from the user
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Create an array of the given size
        int[] arr = new int[size];

        // Get array elements from the user (assumes the array is sorted)
        System.out.println("Enter the sorted elements of the array:");
        for (int i = 0; i < size; i++) {
            arr[i] = scanner.nextInt();
        }

        // Get the target element from the user
        System.out.print("Enter the target element to search: ");
        int target = scanner.nextInt();

        scanner.close();

        // Perform exponential search
        int result = exponentialSearch(arr, target);

        // Display whether the element is found or not
        if (result != -1) {
            System.out.println("Element " + target + " found");
        } else {
            System.out.println("Element " + target + " not found");
        }
    }
}
