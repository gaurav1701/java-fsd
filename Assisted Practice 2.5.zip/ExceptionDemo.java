package Assisted_Practice_Part2;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionDemo {
    public static void main(String[] args) {
        try {
            // Method call that throws an exception
            methodWithException();
        } catch (CustomException e) {
            // Catch and handle custom exception
            System.out.println("Caught custom exception: " + e.getMessage());
        } finally {
            // Finally block: always executed, regardless of whether an exception occurs or not
            System.out.println("Finally block: Executed regardless of exception");
        }
    }

    // Method that throws a checked exception
    public static void methodWithException() throws CustomException {
        // Throw a custom exception
        throw new CustomException("Custom exception thrown");
    }
}