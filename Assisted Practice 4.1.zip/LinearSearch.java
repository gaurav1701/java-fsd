package Assisted_Practice_4;

import java.util.Scanner;

public class LinearSearch {
	
	 // Function to perform linear search
    public static int linearSearch(int[] arr, int target) {
        // Iterate through the array
        for (int i = 0; i < arr.length; i++) {
            // If the current element is equal to the target, return its index
            if (arr[i] == target) {
                return i;
            }
        }
        // If target not found, return -1
        return -1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the size of the array from the user
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Create an array of the given size
        int[] arr = new int[size];

        // Get array elements from the user
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            arr[i] = scanner.nextInt();
        }

        // Get the target element from the user
        System.out.print("Enter the target element to search: ");
        int target = scanner.nextInt();

        scanner.close();

        // Perform linear search
        int result = linearSearch(arr, target);

        // Display whether the element is found or not
        if (result != -1) {
            System.out.println("Element " + target + " found");
        } else {
            System.out.println("Element " + target + " not found");
        }
    }

}
