package Assisted_Practice;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class Program5 {
	
	public static void main(String[] args) {
        // ArrayList
        List<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");

        // LinkedList
        List<Integer> linkedList = new LinkedList<>();
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);

        // Stack
        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(2);
        stack.push(3);

        // Displaying elements of each collection
        System.out.println("ArrayList:");
        System.out.println(arrayList);
        System.out.println("\nLinkedList:");
        System.out.println(linkedList);
        System.out.println("\nStack:");
        System.out.println(stack);
    }

}
