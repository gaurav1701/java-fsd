package com.assisted_practice_program6;

import java.sql.*;

public class DatabaseRecordsExample {
	
	private static final String url = "jdbc:mysql://localhost:3306/student";
    private static final String username = "root";
    private static final String password = "Gaurav@123";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            System.out.println("Connected to database!");

            // Insert a new record
            insertStudent(conn, "John Doe", 25);

            // Update an existing record
            updateStudent(conn, 1, "Jane Smith", 23); // Update student with ID 1

            // Delete a record
            deleteStudent(conn, 2); // Delete student with ID 2

        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void insertStudent(Connection conn, String name, int age) throws SQLException {
        String sql = "INSERT INTO students (name, age) VALUES (?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new student was inserted successfully!");
            }
        }
    }

    private static void updateStudent(Connection conn, int id, String name, int age) throws SQLException {
        String sql = "UPDATE students SET name = ?, age = ? WHERE id = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            statement.setInt(3, id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Student with ID " + id + " was updated successfully!");
            } else {
                System.out.println("No student found with ID " + id);
            }
        }
    }

    private static void deleteStudent(Connection conn, int id) throws SQLException {
        String sql = "DELETE FROM students WHERE id = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, id);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Student with ID " + id + " was deleted successfully!");
            } else {
                System.out.println("No student found with ID " + id);
            }
        }
    }

}
