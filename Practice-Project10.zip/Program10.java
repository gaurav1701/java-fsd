package Assisted_Practice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Program10 {
	
	public static void main(String[] args) {
        // Sample text containing dates
        String text = "The Holi event is scheduled on 25-03-2024 and 26-03-2024.";

        // Regular expression pattern to match dates in the format YYYY-MM-DD
        String pattern = "\\b\\d{2}-\\d{2}-\\d{4}\\b";

        // Creating a Pattern object
        Pattern p = Pattern.compile(pattern);

        // Creating a Matcher object
        Matcher matcher = p.matcher(text);

        // Finding and printing all matches
        System.out.println("Dates found in the text:");
        while (matcher.find()) {
            System.out.println(matcher.group());
        }
    }

}
