package com.assisted_practice_program3;

import java.sql.*;

public class JDBCExample {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/student";
        String username = "root";
        String password = "Gaurav@123";

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            System.out.println("Connected to database!");

            // Step 3: Create and execute a SQL statement
            Statement statement = conn.createStatement();
            String query = "SELECT * FROM student";
            ResultSet resultSet = statement.executeQuery(query);

            // Step 4: Process the ResultSet
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");

                System.out.println("Student ID: " + id);
                System.out.println("Name: " + name);
                System.out.println("Age: " + age);
                System.out.println("--------------------");
            }

        } catch (SQLException e) {
            System.err.println("Error connecting to database: " + e.getMessage());
        }

	}

}
