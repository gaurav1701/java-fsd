package com.assisted_practice_program4;

import java.sql.*;

public class ProcedureExample {
	
	private static final String url = "jdbc:mysql://localhost:3306/student";
    private static final String username = "root";
    private static final String password = "Gaurav@123";

	public static void main(String[] args) {
		
		 try (Connection conn = DriverManager.getConnection(url, username, password)) {
	            System.out.println("Connected to database!");

	            // Call stored procedure to get student by ID
	            int studentId = 1; // Example student ID to retrieve
	            getStudentById(conn, studentId);

	        } catch (SQLException e) {
	            System.err.println("Error: " + e.getMessage());
	        }
	    }

	    private static void getStudentById(Connection conn, int studentId) throws SQLException {
	        // Prepare the stored procedure call
	        String sql = "{CALL getStudentById(?)}";
	        try (CallableStatement callableStatement = conn.prepareCall(sql)) {
	            // Set the input parameter (studentId) for the stored procedure
	            callableStatement.setInt(1, studentId);

	            // Execute the stored procedure
	            boolean hasResults = callableStatement.execute();

	            // Process the result set (if any)
	            if (hasResults) {
	                ResultSet resultSet = callableStatement.getResultSet();
	                if (resultSet.next()) {
	                    int id = resultSet.getInt("id");
	                    String name = resultSet.getString("name");
	                    int age = resultSet.getInt("age");

	                    System.out.println("Student ID: " + id);
	                    System.out.println("Name: " + name);
	                    System.out.println("Age: " + age);
	                } else {
	                    System.out.println("Student with ID " + studentId + " not found.");
	                }
	            }
	        } catch (SQLException e) {
	            System.err.println("Error calling stored procedure: " + e.getMessage());
	        }
		
	}

}
