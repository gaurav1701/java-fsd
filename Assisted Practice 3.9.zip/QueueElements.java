package Assisted_Practice_3;

import java.util.Queue;
import java.util.LinkedList;
import java.util.Scanner;

public class QueueElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue<Integer> queue = new LinkedList<>();

        System.out.print("Enter the number of elements to enqueue into the queue: ");
        int n = scanner.nextInt();

        System.out.println("Enter the elements to enqueue into the queue:");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            queue.add(element);
        }

        System.out.println("Queue elements after enqueuing:");
        System.out.println(queue);

        if (!queue.isEmpty()) {
            int dequeuedElement = queue.remove();
            System.out.println("Dequeued element: " + dequeuedElement);
        } else {
            System.out.println("Queue is empty.");
        }

        System.out.println("Queue elements after dequeuing:");
        System.out.println(queue);

        if (!queue.isEmpty()) {
            int frontElement = queue.peek();
            System.out.println("Front element of the queue: " + frontElement);
        } else {
            System.out.println("Queue is empty.");
        }

        scanner.close();
    }
}