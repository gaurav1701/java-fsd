package com.assisted_practice.servlet_P8;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Counter_Servlet
 */
@WebServlet("/Counter_Servlet")
public class Counter_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Counter_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 // Retrieve or initialize the visit count from the session
        Integer count = (Integer) request.getSession().getAttribute("count");
        if (count == null) {
            count = 0;
        }

        // Increment the visit count
        count++;
        
        // Store the updated count back into the session
        request.getSession().setAttribute("count", count);

        // Set the response content type
        response.setContentType("text/html");

        // Generate HTML form with hidden field to maintain session
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Hidden Form Field Session Tracking</title></head><body>");
        out.println("<h2>Visit Counter</h2>");
        out.println("<p>Number of Visits: " + count + "</p>");
        out.println("<form action=\"CounterServlet\" method=\"post\">");
        out.println("<input type=\"hidden\" name=\"action\" value=\"refresh\">");
        out.println("<input type=\"submit\" value=\"Refresh\">");
        out.println("</form>");
        out.println("</body></html>");
	}

	

}
