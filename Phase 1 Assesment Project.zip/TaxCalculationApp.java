package Phase_1_Assesment_Project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TaxCalculationApp {
    // Scanner for user input
    private static Scanner scanner = new Scanner(System.in);
    // Lists to store properties and vehicles
    private static List<Property> properties = new ArrayList<>();
    private static List<Vehicle> vehicles = new ArrayList<>();

    public static void main(String[] args) {
        displayWelcomeScreen();
        int option = getUserOption();
        while (option != 4) {
            switch (option) {
                case 1:
                    addProperty();
                    break;
                case 2:
                    addVehicle();
                    break;
                case 3:
                    displayTotalTax();
                    break;
                default:
                    System.out.println("Invalid option. Please select a valid option.");
            }
            displayWelcomeScreen();
            option = getUserOption();
        }
        closeApplication();
    }

    // Method to display welcome screen
    private static void displayWelcomeScreen() {
        System.out.println("\nWelcome to Tax Calculation App");
        System.out.println("Developed by [Gaurav Kumar]");
        System.out.println("-------------------------------");
        System.out.println("1. Add Property");
        System.out.println("2. Add Vehicle");
        System.out.println("3. View Total Tax");
        System.out.println("4. Close Application");
        System.out.println("-------------------------------");
    }

    // Method to get user option
    private static int getUserOption() {
        System.out.print("Enter your choice: ");
        return scanner.nextInt();
    }

    // Method to add property
    private static void addProperty() {
        System.out.println("Adding Property");
        System.out.print("Enter base value of the land: ");
        double baseValue = scanner.nextDouble();
        System.out.print("Is the property located in the main city? (Y/N): ");
        boolean inCity = scanner.next().equalsIgnoreCase("Y");
        System.out.print("Enter built-up area (in square feet): ");
        double builtUpArea = scanner.nextDouble();
        System.out.print("Enter age of construction: ");
        int ageOfConstruction = scanner.nextInt();
        // Create Property object and add to list
        Property property = new Property(baseValue, builtUpArea, ageOfConstruction, inCity);
        properties.add(property);
        System.out.println("\nProperty added successfully.");
    }

    // Method to add vehicle
    private static void addVehicle() {
        System.out.println("Adding Vehicle");
        System.out.print("Enter registration number: ");
        String registrationNumber = scanner.next();
        System.out.print("Enter brand of vehicle: ");
        String brand = scanner.next();
        System.out.print("Enter purchase cost (INR): ");
        double purchaseCost = scanner.nextDouble();
        System.out.print("Enter maximum velocity (kmph): ");
        int maxVelocity = scanner.nextInt();
        System.out.print("Enter capacity (number of seats): ");
        int capacity = scanner.nextInt();
        System.out.println("Select type of vehicle:");
        System.out.println("1. Petrol-driven");
        System.out.println("2. Diesel-driven");
        System.out.println("3. CNG/LPG-driven");
        System.out.print("Enter your choice: ");
        int vehicleType = scanner.nextInt();
        // Create Vehicle object and add to list
        Vehicle vehicle = new Vehicle(registrationNumber, brand, purchaseCost, maxVelocity, capacity, vehicleType);
        vehicles.add(vehicle);
        System.out.println("\nVehicle added successfully.");
    }

    // Method to display total tax
    private static void displayTotalTax() {
        System.out.println("\nTotal Tax Summary");
        System.out.println("-----------------");

        double totalPropertyTax = 0;
        double totalVehicleTax = 0;
        
        // Check if properties list is empty
        if (properties.isEmpty()) {
            System.out.println("\nNo properties added.");
        } else {
            // Display total tax for properties
            System.out.println("\nProperties:");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("| %-20s | %-15s | %-20s | %-34s | %-15s |\n", "Base Value", "Built-Up Area", "Age of Construction", "In City", "Tax");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            
            for (Property property : properties) {
                double tax = property.calculateTax();
                totalPropertyTax += tax;
                System.out.printf("| %-20.2f | %-15.2f | %-20d | %-34s | %-15.2f |\n", property.getBaseValue(), property.getBuiltUpArea(), property.getAgeOfConstruction(), property.isInCity(), tax);
            }
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("| %-98s | %-15.2f |\n", "Total Property Tax:", totalPropertyTax);
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
        }

        // Check if vehicles list is empty
        if (vehicles.isEmpty()) {
            System.out.println("\nNo vehicles added.\n");
        } else {
            // Display total tax for vehicles
            System.out.println("\nVehicles:");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("| %-20s | %-15s | %-20s | %-15s | %-16s | %-15s |\n", "Registration No.", "Brand", "Purchase Cost", "Max Velocity", "Capacity", "Tax");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            
            for (Vehicle vehicle : vehicles) {
                double tax = vehicle.calculateTax();
                totalVehicleTax += tax;
                System.out.printf("| %-20s | %-15s | %-20.2f | %-15d | %-16d | %-15.2f |\n", vehicle.getRegistrationNumber(), vehicle.getBrand(), vehicle.getPurchaseCost(), vehicle.getMaxVelocity(), vehicle.getCapacity(), tax);
            }
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("| %-98s | %-15.2f |\n", "Total Vehicle Tax:", totalVehicleTax);
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
        }

        // Display total tax payable
        double totalTaxPayable = totalPropertyTax + totalVehicleTax;
        System.out.printf("| %-98s | %-15.2f |\n", "Total Tax Payable:", totalTaxPayable);
        System.out.println("------------------------------------------------------------------------------------------------------------------------");

        // Provide option to navigate back
        System.out.println("Press any key to return to the main context.");
        scanner.next(); // Wait for user input
    }

    // Method to close application
    private static void closeApplication() {
        System.out.println("Closing Tax Calculation App. Goodbye!");
        scanner.close(); // Close scanner
        System.exit(0);
    }
}