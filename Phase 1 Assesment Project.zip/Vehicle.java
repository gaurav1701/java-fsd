package Phase_1_Assesment_Project;

class Vehicle implements Taxable {
    private String registrationNumber;
    private String brand;
    private double purchaseCost;
    private int maxVelocity;
    private int capacity;
    private int vehicleType;

    // Constructor
    public Vehicle(String registrationNumber, String brand, double purchaseCost, int maxVelocity, int capacity, int vehicleType) {
        this.registrationNumber = registrationNumber;
        this.brand = brand;
        this.purchaseCost = purchaseCost;
        this.maxVelocity = maxVelocity;
        this.capacity = capacity;
        this.vehicleType = vehicleType;
    }

    // Method to calculate vehicle tax
    public double calculateTax() {
        double tax = maxVelocity + capacity;
        switch (vehicleType) {
            case 1:
                tax += 0.1 * purchaseCost; // Petrol-driven
                break;
            case 2:
                tax += 0.11 * purchaseCost; // Diesel-driven
                break;
            case 3:
                tax += 0.12 * purchaseCost; // CNG/LPG-driven
                break;
        }
        return tax;
    }

    // Getter methods
    public String getBrand() {
        return brand;
    }

    public double getPurchaseCost() {
        return purchaseCost;
    }
    
    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public int getMaxVelocity() {
        return maxVelocity;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getVehicleType() {
        return vehicleType;
    }
}