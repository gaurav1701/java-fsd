package Phase_1_Assesment_Project;

public interface Taxable {
	
	double calculateTax();

}
