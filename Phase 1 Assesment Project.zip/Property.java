package Phase_1_Assesment_Project;

class Property implements Taxable {
    private double baseValue;
    private double builtUpArea;
    private int ageOfConstruction;
    private boolean inCity;

    // Constructor
    public Property(double baseValue, double builtUpArea, int ageOfConstruction, boolean inCity) {
        this.baseValue = baseValue;
        this.builtUpArea = builtUpArea;
        this.ageOfConstruction = ageOfConstruction;
        this.inCity = inCity;
    }

    // Method to calculate property tax
    public double calculateTax() {
        double tax;
        if (inCity) {
            tax = (builtUpArea * ageOfConstruction * baseValue) + (0.5 * builtUpArea);
        } else {
            tax = builtUpArea * ageOfConstruction * baseValue;
        }
        return tax;
    }

    // Getter methods
    public double getBaseValue() {
        return baseValue;
    }

    public double getBuiltUpArea() {
        return builtUpArea;
    }
    
    public boolean isInCity() {
        return inCity;
    }

    public int getAgeOfConstruction() {
        return ageOfConstruction;
    }
}