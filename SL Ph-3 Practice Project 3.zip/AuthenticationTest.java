package com.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.eample.Authentication;

public class AuthenticationTest {

	@Test
    public void testAuthenticateUser_ValidAdminCredentials() {
        Authentication auth = new Authentication();
        assertTrue(auth.authenticateUser("admin", "adminpassword"));
    }

    @Test
    public void testAuthenticateUser_ValidUser1Credentials() {
        Authentication auth = new Authentication();
        assertTrue(auth.authenticateUser("user1", "user1password"));
    }

    @Test
    public void testAuthenticateUser_ValidUser2Credentials() {
        Authentication auth = new Authentication();
        assertTrue(auth.authenticateUser("user2", "user2password"));
    }

    @Test
    public void testAuthenticateUser_InvalidCredentials() {
        Authentication auth = new Authentication();
        assertFalse(auth.authenticateUser("user", "wrongPassword"));
    }
}
